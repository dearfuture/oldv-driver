#pragma once
#include "Base.h"
namespace ddk
{
	namespace util
	{
		void write_jmp(VOID *pAddress, ULONG_PTR JumpTo);
	};
};
