
#include "precomp.h"

VOID PtProcessTask ( PPDU Pdu  , PuCONINFO ConInfo)
{
	PROT_Debug(("%s ConInfo 0x%p Pdu 0x%p\n" , __FUNCTION__ , ConInfo , Pdu));	
}