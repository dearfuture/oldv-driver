
#define IDR_ICON	1000

#define IDR_USCSI	1001
#define IDR_DESC	1002
