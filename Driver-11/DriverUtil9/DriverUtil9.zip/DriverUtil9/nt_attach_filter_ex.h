#pragma once
#include "Base.h"
#include "nt_driver.h"
#include "nt_irp_dispatch.h"
#include "lock.h"
#include <functional>
#include <map>
namespace ddk
{
	class nt_attach_filter_ex
	{
		//֧��fastio���˵Ĺ���ģ��

	};
}