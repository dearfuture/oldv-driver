#pragma once
#include "Base.h"
#include "Utils.h"
#include "HookX64.h"
#include "ntos_func_def.h"
#include "native_func_def.h"
void init_tdi_filter();
void terminate_tdi_filter();