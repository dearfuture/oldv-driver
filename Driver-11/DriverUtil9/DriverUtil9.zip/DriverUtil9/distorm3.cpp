
#include "Base.h"
extern "C"
{
#include "3rd/distorm/src/mnemonics.c"
#include "3rd/distorm/src/wstring.c"
#include "3rd/distorm/src/textdefs.c"
//#include "../3rd/distorm/src/x86defs.c"
#include "3rd/distorm/src/prefix.c"
#include "3rd/distorm/src/operands.c"
#include "3rd/distorm/src/insts.c"
#include "3rd/distorm/src/instructions.c"
#include "3rd/distorm/src/distorm.c"
#include "3rd/distorm/src/decoder.c"
};

