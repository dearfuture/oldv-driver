
#include <typeinfo>

type_info::~type_info()
{
}
